# Constants shared across the job_hunt package

